from datetime import date, timedelta
from typing import Optional


# ─── MÉDICAMENT ─────────────────────────────────────────────────────────────

class Medicament:
    _compteur = 0

    def __init__(self, nom: str, dosage: float, forme: str,
                 date_expiration: date, prix: float):
        Medicament._compteur += 1
        self.id = Medicament._compteur
        self.nom = nom
        self.dosage = dosage          # en mg
        self.forme = forme            # "comprimé", "sirop", "injection", …
        self.date_expiration = date_expiration
        self.prix = prix              # prix unitaire en €
        self.stock = Stock(self)

    def est_expire(self) -> bool:
        return date.today() > self.date_expiration

    def __repr__(self):
        return (f"Medicament({self.nom!r}, {self.dosage}mg, "
                f"exp={self.date_expiration}, {self.prix:.2f}€)")


# ─── STOCK ──────────────────────────────────────────────────────────────────

class Stock:
    def __init__(self, medicament: Medicament, quantite: int = 0,
                 seuil_alerte: int = 10):
        self.medicament = medicament
        self.quantite = quantite
        self.seuil_alerte = seuil_alerte

    def verifier_stock(self) -> str:
        if self.quantite == 0:
            return "RUPTURE"
        if self.quantite <= self.seuil_alerte:
            return f"ALERTE — seulement {self.quantite} unité(s) restante(s)"
        return f"OK ({self.quantite} unité(s))"

    def reapprovisionner(self, quantite: int) -> None:
        if quantite <= 0:
            raise ValueError("La quantité doit être positive.")
        self.quantite += quantite
        print(f"[Stock] {self.medicament.nom} réapprovisionné : "
              f"+{quantite} → {self.quantite} unité(s)")

    def retirer(self, quantite: int) -> None:
        if quantite > self.quantite:
            raise ValueError(
                f"Stock insuffisant : {self.quantite} disponible(s), "
                f"{quantite} demandé(s)."
            )
        self.quantite -= quantite

    def est_disponible(self, quantite: int = 1) -> bool:
        return self.quantite >= quantite and not self.medicament.est_expire()

    def __repr__(self):
        return f"Stock({self.medicament.nom!r}, qte={self.quantite})"


# ─── PATIENT ────────────────────────────────────────────────────────────────

class Patient:
    _compteur = 0

    def __init__(self, nom: str, prenom: str, date_naissance: date,
                 allergies: Optional[list[str]] = None):
        Patient._compteur += 1
        self.id = Patient._compteur
        self.nom = nom
        self.prenom = prenom
        self.date_naissance = date_naissance
        self.allergies: list[str] = allergies or []
        self._historique: list["Ordonnance"] = []

    @property
    def age(self) -> int:
        today = date.today()
        return (today - self.date_naissance).days // 365

    def get_historique(self) -> list["Ordonnance"]:
        return list(self._historique)

    def _ajouter_ordonnance(self, ordonnance: "Ordonnance") -> None:
        self._historique.append(ordonnance)

    def __repr__(self):
        return f"Patient({self.prenom} {self.nom}, {self.age} ans)"


# ─── PHARMACIEN ─────────────────────────────────────────────────────────────

class Pharmacien:
    _compteur = 0

    def __init__(self, nom: str, prenom: str, numero_licence: str):
        Pharmacien._compteur += 1
        self.id = Pharmacien._compteur
        self.nom = nom
        self.prenom = prenom
        self.numero_licence = numero_licence

    def valider_ordonnance(self, ordonnance: "Ordonnance") -> bool:
        """Valide une ordonnance et vérifie la disponibilité des médicaments."""
        if not ordonnance.est_valide():
            print(f"[Pharmacien] Ordonnance #{ordonnance.id} expirée ou invalide.")
            return False

        for ligne in ordonnance.lignes:
            if not ligne.medicament.stock.est_disponible(ligne.quantite):
                print(f"[Pharmacien] Stock insuffisant pour "
                      f"{ligne.medicament.nom} (demandé: {ligne.quantite}).")
                return False

            # Vérification allergie
            for allergie in ordonnance.patient.allergies:
                if allergie.lower() in ligne.medicament.nom.lower():
                    print(f"[Pharmacien] ALERTE ALLERGIE : "
                          f"{ordonnance.patient.prenom} est allergique à {allergie}.")
                    return False

        ordonnance.statut = "validée"
        print(f"[Pharmacien] Ordonnance #{ordonnance.id} validée par "
              f"{self.prenom} {self.nom}.")
        return True

    def dispenser_medicament(self, ordonnance: "Ordonnance") -> bool:
        """Dispense les médicaments d'une ordonnance validée."""
        if ordonnance.statut != "validée":
            print("[Pharmacien] Ordonnance non validée, dispensation impossible.")
            return False

        for ligne in ordonnance.lignes:
            ligne.medicament.stock.retirer(ligne.quantite)
            print(f"[Pharmacien] Dispensé : {ligne.quantite}x {ligne.medicament.nom}")

        ordonnance.statut = "dispensée"
        print(f"[Pharmacien] Dispensation terminée. "
              f"Total : {ordonnance.calculer_total():.2f}€")
        return True

    def __repr__(self):
        return f"Pharmacien({self.prenom} {self.nom}, licence={self.numero_licence!r})"


# ─── LIGNE ORDONNANCE ────────────────────────────────────────────────────────

class LigneOrdonnance:
    def __init__(self, medicament: Medicament, quantite: int,
                 posologie: str, duree_traitement: int):
        self.medicament = medicament
        self.quantite = quantite          # nombre d'unités
        self.posologie = posologie        # ex. "1 comprimé matin et soir"
        self.duree_traitement = duree_traitement  # en jours

    def calculer_sous_total(self) -> float:
        return self.quantite * self.medicament.prix

    def __repr__(self):
        return (f"LigneOrdonnance({self.medicament.nom!r}, "
                f"qte={self.quantite}, {self.posologie!r})")


# ─── ORDONNANCE ─────────────────────────────────────────────────────────────

class Ordonnance:
    _compteur = 0

    def __init__(self, patient: Patient, date_validite: Optional[date] = None):
        Ordonnance._compteur += 1
        self.id = Ordonnance._compteur
        self.patient = patient
        self.date_emission = date.today()
        self.date_validite = date_validite or (date.today() + timedelta(days=90))
        self.statut = "en attente"   # "en attente" | "validée" | "dispensée" | "annulée"
        self.lignes: list[LigneOrdonnance] = []
        patient._ajouter_ordonnance(self)

    def ajouter_medicament(self, medicament: Medicament, quantite: int,
                           posologie: str, duree_traitement: int) -> None:
        ligne = LigneOrdonnance(medicament, quantite, posologie, duree_traitement)
        self.lignes.append(ligne)
        print(f"[Ordonnance #{self.id}] Ajout : {quantite}x {medicament.nom}")

    def est_valide(self) -> bool:
        return (self.statut not in ("dispensée", "annulée")
                and date.today() <= self.date_validite)

    def calculer_total(self) -> float:
        return sum(l.calculer_sous_total() for l in self.lignes)

    def afficher_resume(self) -> None:
        print(f"\n{'─'*48}")
        print(f"  Ordonnance #{self.id}")
        print(f"  Patient    : {self.patient.prenom} {self.patient.nom}")
        print(f"  Émise le   : {self.date_emission}  |  Valide jusqu'au : {self.date_validite}")
        print(f"  Statut     : {self.statut.upper()}")
        print(f"{'─'*48}")
        for i, ligne in enumerate(self.lignes, 1):
            print(f"  {i}. {ligne.medicament.nom} ({ligne.medicament.dosage}mg)")
            print(f"     Posologie : {ligne.posologie}")
            print(f"     Durée     : {ligne.duree_traitement} jour(s) "
                  f"| Qté : {ligne.quantite} | "
                  f"Sous-total : {ligne.calculer_sous_total():.2f}€")
        print(f"{'─'*48}")
        print(f"  TOTAL : {self.calculer_total():.2f}€\n")

    def __repr__(self):
        return (f"Ordonnance(#{self.id}, patient={self.patient.nom!r}, "
                f"statut={self.statut!r})")


# ─── DÉMONSTRATION ───────────────────────────────────────────────────────────

if __name__ == "__main__":

    # 1. Créer des médicaments et initialiser le stock
    amoxicilline = Medicament(
        nom="Amoxicilline",
        dosage=500,
        forme="gélule",
        date_expiration=date(2026, 12, 31),
        prix=0.45
    )
    amoxicilline.stock.reapprovisionner(200)

    doliprane = Medicament(
        nom="Doliprane",
        dosage=1000,
        forme="comprimé",
        date_expiration=date(2027, 6, 30),
        prix=0.30
    )
    doliprane.stock.reapprovisionner(500)

    ibuprofene = Medicament(
        nom="Ibuprofène",
        dosage=400,
        forme="comprimé",
        date_expiration=date(2026, 9, 15),
        prix=0.25
    )
    ibuprofene.stock.reapprovisionner(150)

    print("\n=== ÉTAT DU STOCK ===")
    for med in [amoxicilline, doliprane, ibuprofene]:
        print(f"  {med.nom} : {med.stock.verifier_stock()}")

    # 2. Créer un patient et un pharmacien
    patient = Patient(
        nom="Dupont",
        prenom="Marie",
        date_naissance=date(1985, 3, 22),
        allergies=["pénicilline"]
    )

    pharmacien = Pharmacien(
        nom="Martin",
        prenom="Pierre",
        numero_licence="PH-2024-0042"
    )

    # 3. Créer une ordonnance
    ord1 = Ordonnance(patient=patient)
    ord1.ajouter_medicament(
        medicament=doliprane,
        quantite=30,
        posologie="1 comprimé toutes les 6h si douleur",
        duree_traitement=7
    )
    ord1.ajouter_medicament(
        medicament=ibuprofene,
        quantite=20,
        posologie="1 comprimé 3x par jour après les repas",
        duree_traitement=5
    )

    # 4. Tentative avec médicament allergisant
    print("\n=== TEST ALLERGIE (Amoxicilline ≈ pénicilline) ===")
    ord_allergie = Ordonnance(patient=patient)
    ord_allergie.ajouter_medicament(
        medicament=amoxicilline,
        quantite=21,
        posologie="1 gélule 3x par jour",
        duree_traitement=7
    )
    pharmacien.valider_ordonnance(ord_allergie)

    # 5. Validation et dispensation de l'ordonnance valide
    print("\n=== VALIDATION & DISPENSATION ===")
    if pharmacien.valider_ordonnance(ord1):
        pharmacien.dispenser_medicament(ord1)

    ord1.afficher_resume()

    # 6. Historique du patient
    print("=== HISTORIQUE DU PATIENT ===")
    for o in patient.get_historique():
        print(f"  Ordonnance #{o.id} — statut: {o.statut} "
              f"— total: {o.calculer_total():.2f}€")

    # 7. État du stock après dispensation
    print("\n=== STOCK APRÈS DISPENSATION ===")
    for med in [amoxicilline, doliprane, ibuprofene]:
        print(f"  {med.nom} : {med.stock.verifier_stock()}")